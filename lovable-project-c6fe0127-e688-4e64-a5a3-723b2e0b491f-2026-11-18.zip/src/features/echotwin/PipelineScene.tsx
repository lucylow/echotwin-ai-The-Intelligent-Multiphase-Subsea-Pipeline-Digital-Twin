import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Environment, Lightformer, Html } from '@react-three/drei';
import { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { useTwin } from './store';
import { segments } from './model';
import { Button } from '@/components/ui/button';
import { RotateCcw, Scan, Pause, Play, Maximize, ArrowUp, MoveHorizontal } from 'lucide-react';
const points = [new THREE.Vector3(-17,1,-2),new THREE.Vector3(-12,.6,-2),new THREE.Vector3(-8,.4,0),new THREE.Vector3(-3,.5,1),new THREE.Vector3(2,.7,1),new THREE.Vector3(7,.8,-1),new THREE.Vector3(10,1,-3),new THREE.Vector3(11,2,-3),new THREE.Vector3(11,7,-3),new THREE.Vector3(11,11,-3)];
const curve = new THREE.CatmullRomCurve3(points);
function cssColor(name:string) { const c=document.createElement('canvas');c.width=c.height=1;const ctx=c.getContext('2d');if(!ctx)return new THREE.Color();ctx.fillStyle=getComputedStyle(document.documentElement).getPropertyValue(name).trim();ctx.fillRect(0,0,1,1);const d=ctx.getImageData(0,0,1,1).data;return new THREE.Color(d[0]/255,d[1]/255,d[2]/255).convertSRGBToLinear(); }
function Scene({colors,view,reset}:{colors:THREE.Color[];view:string;reset:number}) {
 const {segment,selectSegment,overlay,playing,speed,time,asset}=useTwin();
 const {camera,gl}=useThree();
 const particles=useRef<THREE.InstancedMesh>(null);const phase=useRef(0);const dummy=useMemo(()=>new THREE.Object3D(),[]);
 const pieces=useMemo(()=>segments.map((_,i)=>new THREE.TubeGeometry(new THREE.CatmullRomCurve3(Array.from({length:8},(_,j)=>curve.getPoint((i+j/7)/20))),12,.29,12,false)),[]);
 const terrain=useMemo(()=>{const g=new THREE.PlaneGeometry(80,55,60,45);g.rotateX(-Math.PI/2);const p=g.attributes.position;for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getZ(i);p.setY(i,-.7+Math.sin(x*.25)*Math.cos(z*.23)*.32+Math.sin(x*.8+z*.3)*.08);}g.computeVertexNormals();return g;},[]);
 useEffect(()=>{camera.position.set(...(view==='Top'?[0,40,.01]:view==='Side'?[0,6,37]:view==='Focus'?[curve.getPoint((segment+.5)/20).x+6,9,curve.getPoint((segment+.5)/20).z+9]:[28,22,29]) as [number,number,number]);camera.lookAt(0,3,0);},[camera,view,reset,segment]);
 useFrame((_,dt)=>{gl.domElement.parentElement?.setAttribute('data-scene-ready','true');if(playing)phase.current+=Math.min(dt,.05)*.032*speed;const mesh=particles.current;if(!mesh)return;for(let i=0;i<65;i++){const t=((i/65+phase.current+time/720)%1+1)%1;const p=curve.getPoint(t);dummy.position.copy(p);dummy.position.y+=Math.sin(i*9)*.12;dummy.scale.setScalar(i%4===0?.055:.08);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);mesh.setColorAt(i,colors[5+i%4]);}mesh.instanceMatrix.needsUpdate=true;if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;});
 const colorFor=(i:number)=>{if(overlay==='Risk')return colors[i===13||i===2||i===5?3:2];if(overlay==='Temperature')return colors[i<7?3:i<14?2:1];if(overlay==='Velocity')return colors[i%3===0?2:1];return colors[i<5?3:i<10?2:i<15?1:0];};
 return <>
  <ambientLight intensity={1.2}/><directionalLight position={[0,20,10]} intensity={2.4}/>
  <Environment resolution={64}><Lightformer intensity={3} position={[0,12,0]} scale={[35,20,1]} rotation-x={Math.PI/2}/><Lightformer intensity={2} color={colors[1]} position={[-15,4,10]} scale={[20,10,1]}/></Environment>
  <mesh geometry={terrain}><meshStandardMaterial color={colors[9]} roughness={.95} wireframe={false}/></mesh>
  <gridHelper args={[65,40,colors[10],colors[10]]} position={[0,-.17,0]}/>
  {pieces.map((geo,i)=><group key={`${asset}-${i}`}><mesh geometry={geo} onClick={e=>{e.stopPropagation();selectSegment(i);}}><meshStandardMaterial color={i===segment?colors[4]:colorFor(i)} metalness={.4} roughness={.38} transparent opacity={.85}/></mesh>{i%2===0&&<mesh position={curve.getPoint(i/20)} quaternion={new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),curve.getTangent(i/20))}><cylinderGeometry args={[.4,.4,.14,14]}/><meshStandardMaterial color={colors[10]} metalness={.8} roughness={.3}/></mesh>}</group>)}
  <instancedMesh ref={particles} args={[undefined,undefined,65]}><sphereGeometry args={[1,6,6]}/><meshBasicMaterial/></instancedMesh>
  {[2,5,13].map((i)=><Html key={i} position={curve.getPoint((i+.5)/20)} center distanceFactor={48}><Button variant="secondary" size="sm" className="scene-marker" onClick={()=>selectSegment(i)}><span className="status-dot warning"/>{segments[i].id}</Button></Html>)}
  <Html position={[-18,1,-2]} center><span className="scene-label">INLET · {asset}</span></Html><Html position={[11,12,-3]} center><span className="scene-label">TOPSIDE / OUTLET</span></Html>
  <OrbitControls makeDefault target={[0,3,0]} minDistance={8} maxDistance={70} enableDamping/>
 </>;
}
export default function PipelineScene({large=false}:{large?:boolean}){
 const s=useTwin();const [colors,setColors]=useState<THREE.Color[]>([]);const [view,setView]=useState('Perspective');const [reset,setReset]=useState(0);const [full,setFull]=useState(false);const [cross,setCross]=useState(false);
 useEffect(()=>{setColors(['--viz-blue','--primary','--positive','--warning','--foreground','--phase-gas','--phase-oil','--phase-water','--phase-sand','--seabed','--grid'].map(cssColor));},[]);
 return <div className={`twin-view ${large?'large':''} ${full?'expanded':''}`}>
  <div className="viewer-top"><div className="viewer-caption"><span className="status-dot"/>SUBSEA DIGITAL TWIN <span className="text-muted-foreground">/ {s.asset}</span></div><div className="viewer-modes">{['Pressure','Temperature','Velocity','Risk'].map(m=><Button key={m} variant={s.overlay===m?'secondary':'ghost'} size="sm" onClick={()=>s.setOverlay(m)}>{m}</Button>)}</div></div>
  {colors.length>0&&<Canvas camera={{position:[28,22,29],fov:40}} dpr={1} gl={{antialias:true}}><Scene colors={colors} view={view} reset={reset}/></Canvas>}
  <div className="viewer-side">{[[RotateCcw,'Reset camera'],[ArrowUp,'Top view'],[MoveHorizontal,'Side view'],[Scan,'Focus segment'],[Maximize,'Expand viewer']].map(([Icon,label])=>{const I=Icon as typeof RotateCcw;const l=label as string;return <Button key={l} variant="secondary" size="icon" title={l} aria-label={l} onClick={()=>{if(l==='Expand viewer')setFull(!full);else{setView(l==='Top view'?'Top':l==='Side view'?'Side':l==='Focus segment'?'Focus':'Perspective');setReset(reset+1);}}}><I/></Button>;})}</div>
  {cross&&<div className="cross-section"><h4>Illustrative phase section</h4><div className="phase-section"/><span>Position · {segments[s.segment].id}</span><input aria-label="Cross-section position" type="range" min={0} max={19} value={s.segment} onChange={e=>s.selectSegment(Number(e.target.value))}/></div>}
  <div className="viewer-bottom"><div><span className="small-label">{s.overlay.toUpperCase()} {s.overlay==='Pressure'?'(bar)':s.overlay==='Temperature'?'(°C)':s.overlay==='Velocity'?'(m/s)':'(relative)'}</span><div className="color-scale"/><div className="scale-labels"><span>{s.overlay==='Pressure'?'72':s.overlay==='Temperature'?'8':'Low'}</span><span>{s.overlay==='Pressure'?'85':s.overlay==='Temperature'?'65':'High'}</span></div></div><div className="viewer-bottom-right"><Button variant="ghost" size="sm" onClick={()=>setCross(!cross)}><Scan/>Cross-section</Button><span className="small-label">DEPTH 1,450 m</span></div></div>
  <div className="playback"><Button variant="ghost" size="icon" aria-label={s.playing?'Pause flow':'Resume flow'} onClick={s.togglePlaying}>{s.playing?<Pause/>:<Play/>}</Button><select aria-label="Animation speed" value={s.speed} onChange={e=>s.setSpeed(Number(e.target.value))}><option value={-1}>−1×</option><option value={.5}>0.5×</option><option value={1}>1×</option><option value={2}>2×</option></select><input aria-label="Historical playback" type="range" min={0} max={71} value={s.time} onChange={e=>s.setTime(Number(e.target.value))}/><span className="small-label">{String(Math.floor(s.time/60)).padStart(2,'0')}:{String(s.time%60).padStart(2,'0')}:00</span><span className="synthetic">SYNTHETIC VISUALIZATION</span></div>
 </div>;
}
