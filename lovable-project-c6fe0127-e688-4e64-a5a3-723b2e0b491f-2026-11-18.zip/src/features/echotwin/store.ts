import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { defaults, initialRuns, initialReports, screen, assets, scenarios, type Parameters, type Run, type DemoReport } from './model';
type Audit = {id:string;message:string;time:string};
type Store = {
 asset:string; segment:number; parameters:Parameters; scenario:number; overlay:string; playing:boolean; speed:number; time:number;
 runs:Run[]; reports:DemoReport[]; audit:Audit[]; progress:number; running:boolean; error:string[];
 selectAsset:(id:string)=>void; selectSegment:(i:number)=>void; setParameter:(key:keyof Parameters,value:number)=>void; selectScenario:(i:number)=>void;
 setOverlay:(value:string)=>void; togglePlaying:()=>void; setSpeed:(value:number)=>void; setTime:(value:number)=>void;
 run:()=>void; cancel:()=>void; reset:()=>void; addReport:(title:string,notes:string)=>void; deleteRun:(id:string)=>void; loadRun:(r:Run)=>void; log:(message:string)=>void;
};
import { validate } from './model';
let timer:ReturnType<typeof setInterval>|undefined;
export const useTwin = create<Store>()(persist((set,get)=>({
 asset:'ET-001',segment:13,parameters:{...defaults},scenario:0,overlay:'Pressure',playing:true,speed:1,time:0,
 runs:initialRuns,reports:initialReports,audit:[],progress:0,running:false,error:[],
 log:(message)=>set(s=>({audit:[{id:crypto.randomUUID(),message,time:new Date().toISOString()},...s.audit].slice(0,100)})),
 selectAsset:(id)=>{ const asset=assets.find(a=>a.id===id); if(!asset)return; set({asset:id,parameters:{...defaults,length:asset.length,diameter:asset.diameter,pressure:85+(assets.indexOf(asset)*4)},scenario:0,segment:13,error:[]});get().log(`Selected asset ${id}`); },
 selectSegment:(segment)=>set({segment}),
 setParameter:(key,value)=>{set(s=>({parameters:{...s.parameters,[key]:value}}));get().log(`Changed ${key} to ${value}`);},
 selectScenario:(scenario)=>{const item=scenarios[scenario];if(!item)return;set(s=>({scenario,parameters:{...defaults,length:s.parameters.length,diameter:s.parameters.diameter,...item.patch},error:[]}));get().log(`Selected ${item.name}`);},
 setOverlay:(overlay)=>set({overlay}),togglePlaying:()=>set(s=>({playing:!s.playing})),setSpeed:(speed)=>set({speed}),setTime:(time)=>set({time}),
 run:()=>{if(get().running)return;const error=validate(get().parameters);if(error.length){set({error});return;}set({running:true,progress:0,error:[]});get().log('Simulation started');const snapshot={parameters:{...get().parameters},asset:get().asset,scenario:scenarios[get().scenario].name};timer=setInterval(()=>{const progress=get().progress+1;if(progress>=6){clearInterval(timer);const run:Run={id:`ET-RUN-${Date.now().toString().slice(-7)}`,timestamp:new Date().toISOString(),...snapshot,result:screen(snapshot.parameters)};set(s=>({running:false,progress:6,runs:[run,...s.runs]}));get().log(`Completed ${run.id} · ${screen(snapshot.parameters).velocity.toFixed(2)} m/s`);}else set({progress});},420);},
 cancel:()=>{clearInterval(timer);set({running:false,progress:0});get().log('Simulation cancelled');},
 reset:()=>{clearInterval(timer);set({asset:'ET-001',segment:13,parameters:{...defaults},scenario:0,overlay:'Pressure',playing:true,speed:1,time:0,runs:initialRuns,reports:initialReports,audit:[],progress:0,running:false,error:[]});},
 addReport:(title,notes)=>{const s=get();const run=s.runs.find(r=>r.asset===s.asset)??{id:'ET-PREVIEW',asset:s.asset,scenario:scenarios[s.scenario].name,timestamp:new Date().toISOString(),parameters:s.parameters,result:screen(s.parameters)};set(s=>({reports:[{id:`ET-REP-${Date.now().toString().slice(-7)}`,title,notes,run},...s.reports]}));get().log('Engineering report generated');},
 deleteRun:(id)=>{set(s=>({runs:s.runs.filter(r=>r.id!==id)}));get().log(`Deleted ${id}`);},
 loadRun:(run)=>{set({asset:run.asset,parameters:run.parameters,scenario:Math.max(0,scenarios.findIndex(s=>s.name===run.scenario))});get().log(`Loaded ${run.id}`);},
}),{name:'echotwin-demo-v1',partialize:s=>({asset:s.asset,parameters:s.parameters,scenario:s.scenario,runs:s.runs,reports:s.reports,audit:s.audit})}));
