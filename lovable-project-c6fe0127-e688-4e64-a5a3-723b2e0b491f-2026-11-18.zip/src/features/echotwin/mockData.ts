// Central synthetic data source. All values are fictional demo data, not real measurements.
import { assets } from './model';
export const pipelines = assets.map(a => ({ ...a, synthetic: true as const }));
const types = ['PIPE', 'BEND', 'RISER', 'PIPE', 'JUMPER'] as const;
export const pipelineSegments = pipelines.flatMap((p, pi) => Array.from({ length: 10 }, (_, i) => ({
  id: `${p.id}-SEG-${String(i + 1).padStart(2, '0')}`, assetId: p.id, type: types[i % 5], order: i + 1,
  length: Math.round(p.length / 10), diameter: p.diameter, wallMm: 16 + pi * 2,
  depth: Math.round(p.depth * (1 - (types[i % 5] === 'RISER' ? 0.8 : i / 40))),
})));
const kinds = [['PT', 'Pressure', 'bar'], ['TT', 'Temperature', '°C'], ['FT', 'Flow velocity', 'm/s'], ['VT', 'Vibration', 'mm/s'], ['ST', 'Strain', 'µε'], ['AT', 'Acoustic', 'dB'], ['DT', 'Wall thickness', 'mm'], ['ET', 'Sand / erosion', 'g/s']] as const;
export const syntheticSensors = pipelines.flatMap((p, pi) => kinds.map(([code, label, unit], ki) => ({
  id: `${code}-${pi + 1}0${ki + 1}`, assetId: p.id, segmentId: pipelineSegments[pi * 10 + (ki % 10)].id,
  label, unit, status: (pi + ki) % 7 === 0 ? 'Warning' : 'Online', synthetic: true as const,
})));

// Deterministic generator so the same synthetic values appear on every load.
const rand = (seed: number) => { const x = Math.sin(seed * 9301 + 49297) * 233280; return x - Math.floor(x); };
const base: Record<string, number> = { Pressure: 80, Temperature: 40, 'Flow velocity': 2.5, Vibration: 2.4, Strain: 125, Acoustic: 60, 'Wall thickness': 18, 'Sand / erosion': 0.4 };
export const historicalReadings = syntheticSensors.flatMap((s, si) => Array.from({ length: 64 }, (_, t) => ({
  sensorId: s.id, assetId: s.assetId, timestamp: new Date(Date.UTC(2026, 10, 18) - (63 - t) * 3600000).toISOString(),
  value: +((base[s.label] ?? 1) * (1 + Math.sin(t / 6 + si) * 0.04 + (rand(si * 100 + t) - 0.5) * 0.03)).toFixed(3), synthetic: true as const,
})));
const riskTypes = ['Slugging screening', 'Hydrate screening', 'Erosion screening', 'Leak residual anomaly', 'Free-span screening'];
export const riskEvents = Array.from({ length: 30 }, (_, i) => { const seg = pipelineSegments[(i * 7) % 40]; return {
  id: `ET-RISK-${String(i + 1).padStart(3, '0')}`, assetId: seg.assetId, segmentId: seg.id, type: riskTypes[i % 5],
  severity: ['Low', 'Medium', 'High'][i % 3], confidence: 60 + Math.round(rand(i) * 35), status: ['Open', 'Needs review', 'Under investigation', 'Closed'][i % 4], synthetic: true as const }; });
export const maintenanceRecords = Array.from({ length: 20 }, (_, i) => { const seg = pipelineSegments[(i * 3) % 40]; return {
  id: `ET-MNT-${String(i + 1).padStart(3, '0')}`, assetId: seg.assetId, segmentId: seg.id,
  activity: ['ROV inspection', 'Pigging run', 'Sensor recalibration', 'Anode survey', 'Span rectification'][i % 5],
  date: `2026-${String(1 + (i % 10)).padStart(2, '0')}-${String(5 + i).padStart(2, '0')}`, status: i % 4 === 0 ? 'Scheduled' : 'Completed', synthetic: true as const }; });

// Sample inputs and outputs for the planned "explain sensor patterns" AI feature (synthetic, not real AI output).
export const timeRanges = [
  { id: 'last-12h', label: 'Last 12 hours', hours: 12 },
  { id: 'last-24h', label: 'Last 24 hours', hours: 24 },
  { id: 'last-64h', label: 'Full history (64 h)', hours: 64 },
] as const;
const notes = ['Gradual upward drift above baseline', 'Periodic oscillation consistent with slug cycles', 'Short spike followed by recovery', 'Stable within normal band'];
export const samplePatternExplanations = syntheticSensors.slice(0, 12).map((s, i) => ({
  id: `ET-EXPL-${String(i + 1).padStart(3, '0')}`, sensorId: s.id, assetId: s.assetId, rangeId: timeRanges[i % 3].id,
  summary: `${s.label} (${s.unit}): ${notes[i % 4]}.`, confidence: 65 + (i * 7) % 30, synthetic: true as const,
}));
