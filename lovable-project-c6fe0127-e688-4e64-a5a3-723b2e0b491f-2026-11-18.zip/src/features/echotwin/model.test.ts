import { describe,it,expect } from 'vitest';
import { defaults,screen,validate,assets,segments,sensorReadings,scenarios,initialRuns,risks,agentRecords,initialReports } from './model';
describe('EchoTwin engineering demonstration',()=>{
 it('uses the specified fictional baseline asset',()=>{expect(assets[0]).toMatchObject({id:'ET-001',length:12000,diameter:.25,depth:1450});expect(defaults.pressure).toBe(85);expect(defaults.waterCut).toBe(35);expect(defaults.sand).toBe(25);});
 it('calculates Reynolds number from rho V D / mu',()=>{expect(screen(defaults).reynolds).toBeCloseTo(46125);});
 it('converts simplified friction loss from Pa to bar',()=>{expect(screen(defaults).drop).toBeCloseTo(28.69344);});
 it('rejects composition outside 0–100% or not totaling 100%',()=>{expect(validate({...defaults,oil:36})).toContain('Oil, water, gas and sand fractions must each be within 0–100% and sum to 100%.');expect(validate({...defaults,oil:101,water:-41.1})).not.toHaveLength(0);expect(validate(defaults)).toEqual([]);});
 it('rejects a water cut above 100%',()=>{expect(validate({...defaults,waterCut:101})).toContain('Water cut must be between 0 and 100%.');});
 it('screens water cut, cooling and sand scenarios deterministically',()=>{expect(screen({...defaults,waterCut:55}).slugging).toBeGreaterThan(screen(defaults).slugging);expect(screen({...defaults,temperature:8}).hydrate).toBeGreaterThan(screen(defaults).hydrate);expect(screen({...defaults,sand:90}).erosion).toBeGreaterThan(screen(defaults).erosion);expect(screen(defaults)).toEqual(screen(defaults));});
 it('contains the requested coherent demo records',()=>{expect(assets).toHaveLength(4);expect(segments).toHaveLength(20);expect(sensorReadings.length).toBeGreaterThanOrEqual(500);expect(scenarios).toHaveLength(10);expect(initialRuns).toHaveLength(20);expect(risks).toHaveLength(12);expect(agentRecords).toHaveLength(10);expect(initialReports).toHaveLength(5);});
});
