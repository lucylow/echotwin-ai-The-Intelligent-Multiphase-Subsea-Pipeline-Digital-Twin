export const MODEL = 'ET-SCREEN 1.0';
export const assets = [
  { id: 'ET-001', name: 'North Atlantic Production Line', depth: 1450, length: 12000, diameter: .25 },
  { id: 'ET-002', name: 'Deepwater Gas Export Line', depth: 1820, length: 18000, diameter: .32 },
  { id: 'ET-003', name: 'Subsea Water Injection Line', depth: 980, length: 8500, diameter: .2 },
  { id: 'ET-004', name: 'Multiphase Research Test Loop', depth: 120, length: 1200, diameter: .15 },
];
export type Parameters = { pressure: number; outlet: number; temperature: number; gas: number; liquid: number; waterCut: number; sand: number; diameter: number; length: number; density: number; viscosity: number; oil: number; water: number; gasFraction: number; sandFraction: number; span: number };
export const defaults: Parameters = { pressure: 85, outlet: 72, temperature: 65, gas: 1.8, liquid: .9, waterCut: 35, sand: 25, diameter: .25, length: 12000, density: 820, viscosity: .012, oil: 35, water: 25, gasFraction: 39.9, sandFraction: .1, span: 24 };
export function validate(p: Parameters) {
  const errors: string[] = [];
  for (const [key, value] of Object.entries(p)) if (!Number.isFinite(value) || value < 0) errors.push(`${key}: enter a finite, non-negative value.`);
  if (p.diameter <= 0 || p.length <= 0 || p.viscosity <= 0 || p.density <= 0) errors.push('Diameter, length, density and viscosity must be greater than zero.');
  if (p.waterCut > 100) errors.push('Water cut must be between 0 and 100%.');
  if (p.outlet > p.pressure) errors.push('Outlet pressure cannot exceed inlet pressure in this demo.');
  const fractions = [p.oil, p.water, p.gasFraction, p.sandFraction];
  if (fractions.some(v => v > 100) || Math.abs(fractions.reduce((a,b) => a+b,0)-100) > .001) errors.push('Oil, water, gas and sand fractions must each be within 0–100% and sum to 100%.');
  return [...new Set(errors)];
}
export function screen(p: Parameters) {
  const velocity = p.gas + p.liquid;
  const reynolds = p.density * velocity * p.diameter / p.viscosity;
  const drop = .02 * (p.length / p.diameter) * p.density * velocity ** 2 / 2 / 100000;
  const holdup = velocity > 0 ? p.liquid / velocity : 0;
  const slugging = Math.min(98, Math.max(8, 45 + p.liquid * 22 - p.gas * 10 + p.waterCut * .24));
  const hydrate = Math.min(98, Math.max(4, 48 + p.pressure * .2 - p.temperature * .6 + p.waterCut * .35));
  const erosion = Math.min(98, Math.max(3, p.sand * .6 + velocity * 5));
  return { velocity, reynolds, drop, holdup, froude: velocity / Math.sqrt(9.81 * p.diameter), slugging, hydrate, erosion, period: 34 + 18 / Math.max(.1,p.gas), structural: Math.min(98, p.span * 1.8), confidence: 84 };
}
export type Result = ReturnType<typeof screen>;
export const scenarios = [
  { name: 'Baseline production', description: 'Nominal four-phase production', patch: {} },
  { name: 'Increased water cut', description: 'Water cut elevated to 55%', patch: { waterCut: 55 } },
  { name: 'Reduced gas velocity', description: 'Low gas transport velocity', patch: { gas: .6 } },
  { name: 'Severe-slugging demonstration', description: 'Intermittent riser accumulation', patch: { gas: .3, liquid: 1.6 } },
  { name: 'Cold subsea operation', description: 'Reduced inlet thermal margin', patch: { temperature: 20 } },
  { name: 'Production shutdown', description: 'Zero-flow cooling scenario', patch: { gas: 0, liquid: 0, temperature: 8 } },
  { name: 'Pipeline restart', description: 'Low-rate production recovery', patch: { gas: .8, liquid: .4, temperature: 30 } },
  { name: 'Sand concentration increase', description: 'Elevated solids loading', patch: { sand: 90 } },
  { name: 'Pressure anomaly', description: 'Downstream residual anomaly', patch: { outlet: 60 } },
  { name: 'Structural free-span investigation', description: 'Extended unsupported span', patch: { span: 45 } },
] satisfies { name: string; description: string; patch: Partial<Parameters> }[];
export const segments = Array.from({length:20}, (_,i) => ({ id: i===2 ? 'RISER-003' : i===5 ? 'BEND-006' : `PIPE-${String(i+1).padStart(3,'0')}`, length:600, diameter:.25, wall:18, pressure:85-i*13/19, temperature:65-i*57/19, inclination: i===2 ? 90 : i===5 ? 12 : -1.4 }));
export const risks = Array.from({length:12},(_,i) => ({ id:`ET-RISK-${String(i+1).padStart(3,'0')}`, type:['Slugging screening','Hydrate screening','Erosion screening','Pressure residual anomaly'][i%4], segment:['RISER-003','PIPE-014','BEND-006','PIPE-009'][i%4], confidence:[78,84,69,73][i%4], status:['Needs review','Open','Under investigation'][i%3] }));
export const sensorDefs = [ ['PT-001','Inlet pressure','bar',85], ['PT-002','Outlet pressure','bar',72], ['TT-001','Inlet temperature','°C',65], ['TT-002','Riser temperature','°C',8], ['FT-001','Gas superficial velocity','m/s',1.8], ['FT-002','Liquid superficial velocity','m/s',.9], ['VT-001','Riser vibration','mm/s',2.4], ['ST-001','Pipeline strain','µε',125] ] as const;
export function readings(base:number, count=72, intensity=1, offset=0) { return Array.from({length:count},(_,i) => ({ time: i, pressure: +(base + Math.sin(i*.32+offset)*intensity + Math.cos(i*.73)*intensity*.3).toFixed(2), temperature: +(65-i*.15+Math.sin(i*.2)).toFixed(2), velocity: +(2.7+Math.sin(i*.2)*.12).toFixed(2) })); }
export const sensorReadings = sensorDefs.flatMap((s,index) => readings(s[3],72,.025*s[3],index).map(r=>({...r,sensor:s[0]})));
export type Run = { id:string; asset:string; scenario:string; timestamp:string; parameters:Parameters; result:Result };
export const initialRuns:Run[] = Array.from({length:20},(_,i)=> { const p={...defaults,...scenarios[i%10].patch}; return { id:`ET-RUN-${String(1042-i).padStart(4,'0')}`, asset:'ET-001', scenario:scenarios[i%10].name, timestamp:`2026-11-${String(18-Math.floor(i/4)).padStart(2,'0')}T${String(14+i%4).padStart(2,'0')}:32:00Z`, parameters:p, result:screen(p) }; });
export const agentRecords = Array.from({length:10},(_,i)=>({id:`AG-${100+i}`, agent:['Physics Validator','Simulation Agent','Risk Evaluator','Flow Assurance','Structural Integrity'][i%5],state:'Completed',source:MODEL}));
export type DemoReport = {id:string;title:string;run:Run;notes:string};
export const initialReports:DemoReport[] = initialRuns.slice(0,5).map((run,i)=>({id:`ET-REP-${101+i}`,title:`${run.scenario} · engineering screening`,run,notes:''}));
export const navigation = [
  { section:'WORKSPACE', items:[['dashboard','Overview','LayoutDashboard'],['digital-twin','3D digital twin','Box'],['simulation','Simulation','FlaskConical']] },
  { section:'ENGINEERING INTELLIGENCE', items:[['flow-assurance','Flow assurance','Waves'],['slugging','Severe slugging','Activity'],['hydrate-intelligence','Hydrate intelligence','Snowflake'],['erosion','Erosion & sand','Wind'],['leak-detection','Leak detection','Radar'],['structural-integrity','Structural integrity','ShieldCheck']] },
  { section:'DATA & OPERATIONS', items:[['sensors','Sensor monitoring','Radio'],['ai-agents','AI engineering agents','Bot'],['scenarios','Scenario library','Layers'],['reports','Engineering reports','FileText'],['asset-management','Asset management','Network']] },
] as const;
export const pages = Object.fromEntries(navigation.flatMap(g=>g.items.map(i=>[i[0],i[1]])));
