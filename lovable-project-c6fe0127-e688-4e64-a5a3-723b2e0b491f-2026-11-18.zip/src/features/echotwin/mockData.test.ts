import { describe, it, expect } from 'vitest';
import { pipelines, pipelineSegments, syntheticSensors } from './mockData';
describe('mock data', () => {
  it('has 4 pipelines', () => expect(pipelines).toHaveLength(4));
  it('has 40 linked segments', () => { expect(pipelineSegments).toHaveLength(40); expect(pipelineSegments.every(s => pipelines.some(p => p.id === s.assetId))).toBe(true); });
  it('has 32 linked sensors', () => { expect(syntheticSensors).toHaveLength(32); expect(syntheticSensors.every(s => pipelineSegments.some(g => g.id === s.segmentId && g.assetId === s.assetId))).toBe(true); });
});
import { historicalReadings, riskEvents, maintenanceRecords } from './mockData';
describe('extended mock data', () => {
  it('has at least 2000 readings', () => expect(historicalReadings.length).toBeGreaterThanOrEqual(2000));
  it('has 30 risk events', () => expect(riskEvents).toHaveLength(30));
  it('has 20 maintenance records', () => expect(maintenanceRecords).toHaveLength(20));
});
import { samplePatternExplanations, timeRanges } from './mockData';
it('has 12 sample explanations linked to sensors and ranges', () => { expect(samplePatternExplanations).toHaveLength(12); expect(samplePatternExplanations.every(e => syntheticSensors.some(s => s.id === e.sensorId) && timeRanges.some(r => r.id === e.rangeId))).toBe(true); });
