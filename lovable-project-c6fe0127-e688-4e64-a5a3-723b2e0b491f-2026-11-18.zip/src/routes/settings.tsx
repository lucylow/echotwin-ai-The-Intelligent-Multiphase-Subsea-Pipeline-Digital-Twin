import { createFileRoute } from '@tanstack/react-router';
import { Workspace } from '@/features/echotwin/Workspace';
export const Route = createFileRoute('/settings')({
 ssr: false,
 head: () => ({meta:[{title:'Settings | EchoTwin AI'},{name:'description',content:'Settings: synthetic subsea pipeline visualization, deterministic screening and traceable engineering evidence.'},{property:'og:title',content:'Settings | EchoTwin AI'},{property:'og:description',content:'Explore settings for your subsea pipeline digital twin. Synthetic demonstration data only.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),
 component: Page,
});
function Page() { return <Workspace page="settings"/>; }
