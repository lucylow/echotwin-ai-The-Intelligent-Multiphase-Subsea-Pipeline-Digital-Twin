import { createFileRoute } from '@tanstack/react-router';
import { Workspace } from '@/features/echotwin/Workspace';
export const Route = createFileRoute('/hydrate-intelligence')({
 ssr: false,
 head: () => ({meta:[{title:'Hydrate Intelligence | EchoTwin AI'},{name:'description',content:'Hydrate Intelligence: synthetic subsea pipeline visualization, deterministic screening and traceable engineering evidence.'},{property:'og:title',content:'Hydrate Intelligence | EchoTwin AI'},{property:'og:description',content:'Explore hydrate intelligence for your subsea pipeline digital twin. Synthetic demonstration data only.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),
 component: Page,
});
function Page() { return <Workspace page="hydrate-intelligence"/>; }
