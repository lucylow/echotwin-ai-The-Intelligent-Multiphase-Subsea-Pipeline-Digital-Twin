import { createFileRoute } from '@tanstack/react-router';
import { Workspace } from '@/features/echotwin/Workspace';
export const Route = createFileRoute('/structural-integrity')({
 ssr: false,
 head: () => ({meta:[{title:'Structural Integrity | EchoTwin AI'},{name:'description',content:'Structural Integrity: synthetic subsea pipeline visualization, deterministic screening and traceable engineering evidence.'},{property:'og:title',content:'Structural Integrity | EchoTwin AI'},{property:'og:description',content:'Explore structural integrity for your subsea pipeline digital twin. Synthetic demonstration data only.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),
 component: Page,
});
function Page() { return <Workspace page="structural-integrity"/>; }
