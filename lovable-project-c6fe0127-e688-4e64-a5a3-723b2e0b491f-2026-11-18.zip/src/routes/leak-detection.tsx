import { createFileRoute } from '@tanstack/react-router';
import { Workspace } from '@/features/echotwin/Workspace';
export const Route = createFileRoute('/leak-detection')({
 ssr: false,
 head: () => ({meta:[{title:'Leak Detection | EchoTwin AI'},{name:'description',content:'Leak Detection: synthetic subsea pipeline visualization, deterministic screening and traceable engineering evidence.'},{property:'og:title',content:'Leak Detection | EchoTwin AI'},{property:'og:description',content:'Explore leak detection for your subsea pipeline digital twin. Synthetic demonstration data only.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),
 component: Page,
});
function Page() { return <Workspace page="leak-detection"/>; }
