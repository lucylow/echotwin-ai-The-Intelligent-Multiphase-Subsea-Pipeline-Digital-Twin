import { createFileRoute } from '@tanstack/react-router';
import { Workspace } from '@/features/echotwin/Workspace';
export const Route = createFileRoute('/reports')({
 ssr: false,
 head: () => ({meta:[{title:'Reports | EchoTwin AI'},{name:'description',content:'Reports: synthetic subsea pipeline visualization, deterministic screening and traceable engineering evidence.'},{property:'og:title',content:'Reports | EchoTwin AI'},{property:'og:description',content:'Explore reports for your subsea pipeline digital twin. Synthetic demonstration data only.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),
 component: Page,
});
function Page() { return <Workspace page="reports"/>; }
