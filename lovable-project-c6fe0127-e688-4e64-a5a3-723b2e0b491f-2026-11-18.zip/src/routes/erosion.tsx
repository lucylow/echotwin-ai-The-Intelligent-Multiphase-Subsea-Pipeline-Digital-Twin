import { createFileRoute } from '@tanstack/react-router';
import { Workspace } from '@/features/echotwin/Workspace';
export const Route = createFileRoute('/erosion')({
 ssr: false,
 head: () => ({meta:[{title:'Erosion | EchoTwin AI'},{name:'description',content:'Erosion: synthetic subsea pipeline visualization, deterministic screening and traceable engineering evidence.'},{property:'og:title',content:'Erosion | EchoTwin AI'},{property:'og:description',content:'Explore erosion for your subsea pipeline digital twin. Synthetic demonstration data only.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),
 component: Page,
});
function Page() { return <Workspace page="erosion"/>; }
