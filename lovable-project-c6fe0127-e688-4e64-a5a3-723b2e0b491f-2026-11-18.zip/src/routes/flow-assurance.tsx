import { createFileRoute } from '@tanstack/react-router';
import { Workspace } from '@/features/echotwin/Workspace';
export const Route = createFileRoute('/flow-assurance')({
 ssr: false,
 head: () => ({meta:[{title:'Flow Assurance | EchoTwin AI'},{name:'description',content:'Flow Assurance: synthetic subsea pipeline visualization, deterministic screening and traceable engineering evidence.'},{property:'og:title',content:'Flow Assurance | EchoTwin AI'},{property:'og:description',content:'Explore flow assurance for your subsea pipeline digital twin. Synthetic demonstration data only.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),
 component: Page,
});
function Page() { return <Workspace page="flow-assurance"/>; }
