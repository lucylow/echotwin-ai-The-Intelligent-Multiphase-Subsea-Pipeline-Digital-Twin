import { createFileRoute } from '@tanstack/react-router';
import { Workspace } from '@/features/echotwin/Workspace';
export const Route = createFileRoute('/')({
 ssr: false,
 head: () => ({meta:[{title:'EchoTwin AI engineering command center | EchoTwin AI'},{name:'description',content:'EchoTwin AI engineering command center: synthetic subsea pipeline visualization, deterministic screening and traceable engineering evidence.'},{property:'og:title',content:'EchoTwin AI engineering command center | EchoTwin AI'},{property:'og:description',content:'Explore echotwin ai engineering command center for your subsea pipeline digital twin. Synthetic demonstration data only.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),
 component: Page,
});
function Page() { return <Workspace page="dashboard"/>; }
