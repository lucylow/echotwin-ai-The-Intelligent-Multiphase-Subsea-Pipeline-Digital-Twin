import { createFileRoute } from '@tanstack/react-router';
import { Workspace } from '@/features/echotwin/Workspace';
export const Route = createFileRoute('/asset-management')({
 ssr: false,
 head: () => ({meta:[{title:'Asset Management | EchoTwin AI'},{name:'description',content:'Asset Management: synthetic subsea pipeline visualization, deterministic screening and traceable engineering evidence.'},{property:'og:title',content:'Asset Management | EchoTwin AI'},{property:'og:description',content:'Explore asset management for your subsea pipeline digital twin. Synthetic demonstration data only.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),
 component: Page,
});
function Page() { return <Workspace page="asset-management"/>; }
