import { createFileRoute } from '@tanstack/react-router';
import { Workspace } from '@/features/echotwin/Workspace';
export const Route = createFileRoute('/digital-twin')({
 ssr: false,
 head: () => ({meta:[{title:'Digital Twin | EchoTwin AI'},{name:'description',content:'Digital Twin: synthetic subsea pipeline visualization, deterministic screening and traceable engineering evidence.'},{property:'og:title',content:'Digital Twin | EchoTwin AI'},{property:'og:description',content:'Explore digital twin for your subsea pipeline digital twin. Synthetic demonstration data only.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),
 component: Page,
});
function Page() { return <Workspace page="digital-twin"/>; }
