import { createFileRoute } from '@tanstack/react-router';
import { Workspace } from '@/features/echotwin/Workspace';
export const Route = createFileRoute('/dashboard')({
 ssr: false,
 head: () => ({meta:[{title:'Pipeline overview | EchoTwin AI'},{name:'description',content:'Pipeline overview: synthetic subsea pipeline visualization, deterministic screening and traceable engineering evidence.'},{property:'og:title',content:'Pipeline overview | EchoTwin AI'},{property:'og:description',content:'Explore pipeline overview for your subsea pipeline digital twin. Synthetic demonstration data only.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),
 component: Page,
});
function Page() { return <Workspace page="dashboard"/>; }
