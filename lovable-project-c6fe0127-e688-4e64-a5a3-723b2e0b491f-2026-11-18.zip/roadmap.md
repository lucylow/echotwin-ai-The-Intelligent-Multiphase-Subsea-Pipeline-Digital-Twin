# EchoTwin AI
- [ ] Shared engineering shell and all requested routes
- [ ] Deterministic data, screening engine, simulation history and tests
- [ ] Interactive 3D pipeline, overlays, segment inspection and playback
- [ ] Engineering analysis, sensors, scenarios and demo copilot
- [ ] Reports, audit trail, browser verification and commit